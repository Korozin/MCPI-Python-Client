import minecraft.minecraft as minecraft

mc = minecraft.Minecraft.create()

mc.setting("nametags_visible", False)