# MCPI Hacks / MCPI Enhancer
by MegaTKC

## Requirements
- Minecraft-PI / Minecraft-Pi-Reborn
- Python 2.7

## Usage
Download this repo from git clone or from zip. If downloaded repo from zip you must extract it. Now open the repo and run python2 app.py. These hacks are in real clients such as WURST, Sigma and Zeroday.
  
### Known Issues and Bugs
- Hacks such as scaffold are invisible to players, so users / mobs can walk through your client-side blocks. When in the sky with scaffold players will see you walking on invisible blocks or just floating in the air. You can run this in survival mode and creative mode in MCPI.
- To stop Scaffold or ChatSpammer, you need to go into the terminal and hit CTRL + C on your keyboard to remove the previously selected module.
  

## Changelog (0.2)
- Added NameTags
- Renamed to MCPI Enhancer
- Added AutoJump
- Added GUI for Ease of use

### Join my Minecraft-Pi Server!
- nitro.pocket-server.net:19132

